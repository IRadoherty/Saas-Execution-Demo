﻿using System.Net;
using System.Net.Http.Headers;
using System.Text;
using SaaS_Execution_Demo.Models.Requests;
using SaaS_Execution_Demo.Models.Responses;
using Newtonsoft.Json;

namespace SaaS_Execution_Demo.Services
{
    public class ExecutionService
    {
        public async Task<RuleExecution.Response> irServerPost(ApplyRules.Request request, string ExecutionServiceUrl,
            string Authorization)
        {
            using var client = new HttpClient();
            client.BaseAddress = new Uri(ExecutionServiceUrl);
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Authorization);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var requestJson = JsonConvert.SerializeObject(request);
            var first = requestJson.FirstOrDefault();
            var content = new StringContent(requestJson, Encoding.UTF8, "application/json");

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync(ExecutionServiceUrl, content);
            var responseString = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<RuleExecution.Response>(responseString) ??
                   throw new InvalidOperationException();
        }
    }
}