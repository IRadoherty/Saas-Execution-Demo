﻿using SaaS_Execution_Demo.Models.Requests;

namespace SaaS_Execution_Demo.Models.Responses
{
    public class RuleExecution
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        public class Response
        {
            public List<ActiveNotification> ActiveNotifications { get; set; }
            public List<ActiveValidation> ActiveValidations { get; set; }
            public string EntityState { get; set; }
            public bool HasRuntimeErrors { get; set; }
            public List<ApplyRules.Override> Overrides { get; set; }
            public List<Parameter> Parameters { get; set; }
            public string RequestId { get; set; }
            public RuleExecutionLog RuleExecutionLog { get; set; }
            public string RuleSessionState { get; set; }
            public string SessionId { get; set; }
        }
        public class ActiveNotification
        {
            public string ElementId { get; set; }
            public bool IsActive { get; set; }
            public string Message { get; set; }
            public string NotificationType { get; set; }
        }

        public class ActiveValidation
        {
            public string ElementIdentifier { get; set; }
            public string InvalidMessageText { get; set; }
            public bool IsValid { get; set; }
            public List<Reason> Reasons { get; set; }
        }

        public class Message
        {
            public string Description { get; set; }
            public int ChangeType { get; set; }
            public long CollectionCount { get; set; }
            public string CollectionId { get; set; }
            public string MemberId { get; set; }
            public long MemberIndex { get; set; }
        }

        //public class Override
        //{
        //    public string Name { get; set; }
        //    public int OverrideType { get; set; }
        //    public string PropertyName { get; set; }
        //    public string Value { get; set; }
        //}

        public class Parameter
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        public class Reason
        {
            public string FiringRuleId { get; set; }
            public string MessageText { get; set; }
        }



        public class RuleExecutionLog
        {
            public List<Message> Messages { get; set; }
            public long TotalEvaluationCycles { get; set; }
            public string TotalExecutionTime { get; set; }
            public long TotalTraceFrames { get; set; }
        }


    }
}
